#include <iostream>
using namespace std;

int main() {
    int n, capacity, page_faults = 0, page_hits = 0;

    cout << "Enter number of reference string elements: ";
    cin >> n;
    int pages[100];
    cout << "Enter the reference string: ";
    for (int i = 0; i < n; i++) cin >> pages[i];

    cout << "Enter frame capacity: ";
    cin >> capacity;
    int frames[10], last_used_time[10];
    for (int i = 0; i < capacity; i++) {
        frames[i] = -1;
        last_used_time[i] = 0;
    }

    cout << "\nIncoming\tFrame State\n";
    for (int i = 0; i < n; i++) {
        bool is_hit = false;
        int hit_index = -1;

        // Check for Page Hit
        for (int j = 0; j < capacity; j++) {
            if (frames[j] == pages[i]) {
                is_hit = true;
                hit_index = j;
                page_hits++;
                break;
            }
        }

        if (is_hit) {
            // Update time stamp for the hit frame slot
            last_used_time[hit_index] = i;
        } else {
            // Check if there is an empty slot available first
            int empty_slot_idx = -1;
            for (int j = 0; j < capacity; j++) {
                if (frames[j] == -1) {
                    empty_slot_idx = j;
                    break;
                }
            }

            if (empty_slot_idx != -1) {
                frames[empty_slot_idx] = pages[i];
                last_used_time[empty_slot_idx] = i;
            } else {
                // If frames are full, find the least recently used frame index
                int lru_idx = 0;
                int minimum_time = last_used_time[0];
                for (int j = 1; j < capacity; j++) {
                    if (last_used_time[j] < minimum_time) {
                        minimum_time = last_used_time[j];
                        lru_idx = j;
                    }
                }
                frames[lru_idx] = pages[i];
                last_used_time[lru_idx] = i;
            }
            page_faults++;
        }


        cout << pages[i] << "\t\t";
        for (int j = 0; j < capacity; j++) {
            if (frames[j] != -1) cout << frames[j] << " ";
            else cout << "- ";
        }
        if (is_hit) cout << "(Hit)";
        else cout << "(Fault)";
        cout << endl;
    }

    cout << "\nTotal Page Faults = " << page_faults << endl;
    cout << "Total Page Hits = " << page_hits << endl;
    return 0;
}

