#include <iostream>
using namespace std;

int main() {
    int n, capacity, page_faults = 0, page_hits = 0, index = 0;

    cout << "Enter number of reference string elements: ";
    cin >> n;
    int pages[100];
    cout << "Enter the reference string: ";
    for (int i = 0; i < n; i++) cin >> pages[i];

    cout << "Enter frame capacity: ";
    cin >> capacity;
    int frames[10];
    for (int i = 0; i < capacity; i++) frames[i] = -1; // Initialize empty frames with -1

    cout << "\nIncoming\tFrame State\n";
    for (int i = 0; i < n; i++) {
        bool is_hit = false;

        // Check if page already exists in frames
        for (int j = 0; j < capacity; j++) {
            if (frames[j] == pages[i]) {
                is_hit = true;
                page_hits++;
                break;
            }
        }

        // If page is not in frames (Page Fault)
        if (!is_hit) {
            frames[index] = pages[i];
            index = (index + 1) % capacity;
            page_faults++;
        }


        cout << pages[i] << "\t\t";
        for (int j = 0; j < capacity; j++) {
            if (frames[j] != -1) cout << frames[j] << " ";
            else cout << "- ";
        }
        if (is_hit) cout << "(Hit)";
        else cout << "(Fault)";
        cout << endl;
    }

    cout << "\nTotal Page Faults = " << page_faults << endl;
    cout << "Total Page Hits = " << page_hits << endl;
    return 0;
}

