#include <iostream>
using namespace std;

struct Process {
    int id;
    int arrival;
    int burst;
    int priority;
    int completion;
    int turnaround;
    int waiting;
    bool is_completed;
};

int main() {
    int n;
    float total_tat = 0, total_wt = 0;

    cout << "Enter number of processes: ";
    cin >> n;

    Process p[100];
    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        cout << "Enter Arrival Time, Burst Time, and Priority for Process P" << p[i].id << ": ";
        cin >> p[i].arrival >> p[i].burst >> p[i].priority;
        p[i].is_completed = false; // Initially, no process is completed
    }

    int current_time = 0;
    int completed = 0;

    while (completed < n) {
        int highest_priority_idx = -1;
        int highest_priority_value = 1e9;

        // Find the process that has arrived and has the highest priority
        for (int i = 0; i < n; i++) {
            if (p[i].arrival <= current_time && !p[i].is_completed) {
                if (p[i].priority < highest_priority_value) {
                    highest_priority_value = p[i].priority;
                    highest_priority_idx = i;
                }
                // If priorities are equal, pick the one that arrived first
                else if (p[i].priority == highest_priority_value) {
                    if (p[i].arrival < p[highest_priority_idx].arrival) {
                        highest_priority_idx = i;
                    }
                }
            }
        }

        // If a process is found, execute it completely
        if (highest_priority_idx != -1) {
            p[highest_priority_idx].completion = current_time + p[highest_priority_idx].burst;
            p[highest_priority_idx].turnaround = p[highest_priority_idx].completion - p[highest_priority_idx].arrival;
            p[highest_priority_idx].waiting = p[highest_priority_idx].turnaround - p[highest_priority_idx].burst;

            total_tat += p[highest_priority_idx].turnaround;
            total_wt += p[highest_priority_idx].waiting;

            current_time = p[highest_priority_idx].completion;
            p[highest_priority_idx].is_completed = true;
            completed++;
        }
        else {
            // If no process has arrived yet, CPU sits idle
            current_time++;
        }
    }

    // Print the results table
    cout << "\nProcess\tArrival\tBurst\tPriority\tCompletion\tTurnaround\tWaiting\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id << "\t" << p[i].arrival << "\t" << p[i].burst << "\t"
             << p[i].priority << "\t\t" << p[i].completion << "\t\t" << p[i].turnaround << "\t\t" << p[i].waiting << "\n";
    }

    cout << "\nAverage Turnaround Time = " << total_tat / n << endl;
    cout << "Average Waiting Time = " << total_wt / n << endl;

    return 0;
}

